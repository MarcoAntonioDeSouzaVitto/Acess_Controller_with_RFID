from flask import Flask, render_template, request, jsonify, redirect
import sqlite3
from pathlib import Path
from datetime import datetime
import time
ultimo_sinal = None

app = Flask(__name__)

databd = Path(__file__).resolve().parent / "database_iot.db"

def conectar_banco():
    conexao = sqlite3.connect(databd, timeout=15)
    conexao.row_factory = sqlite3.Row
    return conexao

def iniciar_banco():
    conexao = conectar_banco()
    cursor = conexao.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS usuarios (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            uid TEXT NOT NULL UNIQUE
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS registros (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            uid TEXT NOT NULL,
            acesso TEXT NOT NULL,
            data_hora TEXT NOT NULL
        )
    """)

    conexao.commit()
    conexao.close()
#======================

@app.route("/api/esp/status", methods=["GET", "POST"])
def status_esp():
    global ultimo_sinal
    if request.method == "POST":
        ultimo_sinal = time.time()
        return jsonify({"mensagem": "Heartbeat recebido"}), 200
    if ultimo_sinal is None:
        return jsonify({"online": False})
    tempo_decorrido = time.time() - ultimo_sinal
    online = tempo_decorrido <= 15
    return jsonify({"online": online, "ultima_comunicacao": round(tempo_decorrido, 1)})
#======================
@app.route("/")
def pagina_inicial():
    return redirect("/first_page")
@app.route("/first_page")
def inicioSite():
    return render_template("first_page.html")

@app.route("/second_page")
def menu():
    return render_template("second_page.html")

@app.route("/historico")
def historico():
    return render_template("historico.html")
@app.route("/controle")
def controledados():
    return render_template("controle.html")
@app.route("/visitante")
def visitantelogin():
    return render_template("visitante.html")

#=================================

@app.route("/api/registros")
def listar_registros():
    ultimo_id = request.args.get("ultimo_id", type=int)
    conexao = conectar_banco()
    cursor = conexao.cursor()
    if ultimo_id is None:
        cursor.execute("""
            SELECT * FROM (SELECT id, uid, acesso, data_hora FROM registros ORDER BY id DESC LIMIT 5) ORDER BY id ASC""")
    else:
        cursor.execute("""SELECT id,uid,acesso,data_hora FROM registros WHERE id > ? ORDER BY id ASC""",(ultimo_id,))
    registrosBanco = cursor.fetchall()
    conexao.close()

    return jsonify([dict(registro) for registro in registrosBanco])

#=================================

@app.route("/api/leitura", methods=['POST'])
def itens_lidos():
    conexao = conectar_banco()
    cursor = conexao.cursor()
    dados = request.get_json()
    if not dados:
        return jsonify({"status":"error","message":"Nenhum dado Json fornecido"}), 400
    uid = dados.get("uid")
    cursor.execute("SELECT uid FROM usuarios WHERE uid = ?",(uid,))
    consulta = cursor.fetchall()
    if consulta:
        acesso = "Liberado"
    else:
        acesso = "Negado"
    datahora = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    cursor.execute("INSERT INTO registros(uid, acesso, data_hora) VALUES(?,?,?)",(uid,acesso,datahora))
    conexao.commit()
    conexao.close()
    return jsonify({"uid":uid, "acesso":acesso,"data_hora":datahora}),200

#=================================

registros_limite = 15
@app.route("/api/historico")
def historicogeral():
    pagina = request.args.get("pagina", default=1, type=int)
    pagina = max(1,pagina)
    offset = (pagina -1) * registros_limite
    conexao = conectar_banco()
    cursor = conexao.cursor()
    cursor.execute("SELECT COUNT(*) FROM registros;")
    total_registros = cursor.fetchone()[0]
    total_paginas = max(1, (total_registros + registros_limite - 1) // registros_limite)
    cursor.execute("SELECT id, uid, acesso, data_hora FROM registros ORDER BY id desc LIMIT ? OFFSET ?;",(registros_limite,offset))
    dados = [dict(linha) for linha in cursor.fetchall()]
    conexao.close()
    return jsonify({     
        "registros": dados,
        "pagina_atual": pagina,
        "total_paginas": total_paginas,
        "total_registros": total_registros
    })
#=================================

registrosUser_limite = 8
@app.route("/api/controle")
def usuariosRegistrados():
    pagina = request.args.get("pagina", default=1, type=int)
    pagina = max(1,pagina)
    offset = (pagina -1) * registrosUser_limite
    conexao = conectar_banco()
    cursor = conexao.cursor()
    cursor.execute("SELECT COUNT(*) FROM usuarios;")
    total_registrosUSER = cursor.fetchone()[0]
    total_paginas = max(1, (total_registrosUSER + registrosUser_limite - 1) // registrosUser_limite)
    cursor.execute("SELECT id, nome, uid FROM usuarios ORDER BY id asc LIMIT ? OFFSET ?;",(registrosUser_limite,offset))
    dados = [dict(linha) for linha in cursor.fetchall()]
    conexao.close()
    return jsonify({     
        "registros": dados,
        "pagina_atual": pagina,
        "total_paginas": total_paginas,
        "total_registros": total_registrosUSER
    })
#=================================

@app.route("/adicionar_usuario",methods=["POST"])
def adicionar_usuario():
    nome = request.form["nome"]
    uidusuario = request.form["uiduser"]
    conexao = conectar_banco()
    cursor = conexao.cursor()
    cursor.execute("""INSERT INTO usuarios(nome,uid) VALUES(?,?)""",(nome,uidusuario))
    conexao.commit()
    conexao.close()
    return redirect("/controle")
#=================================

@app.route("/remover_usuario/<int:id>",methods=["POST"])
def remover_usuario(id):
    conexao = conectar_banco()
    cursor = conexao.cursor()
    cursor.execute("DELETE FROM usuarios WHERE id = ?",(id,))
    conexao.commit()
    conexao.close()
    return redirect("/controle")
#=================================

@app.route("/api/visitante")
def listarParaVistiante():
    ultimo_id = request.args.get("ultimo_id", default=0,type=int)
    conexao = conectar_banco()
    cursor = conexao.cursor()
    cursor.execute("""SELECT id,uid,acesso FROM registros WHERE id > ? ORDER BY id ASC""",(ultimo_id,))
    registrosBanco = cursor.fetchall()
    conexao.close()
    return jsonify([dict(registro) for registro in registrosBanco])
if __name__ == "__main__":
    iniciar_banco()
    app.run(host="0.0.0.0", port=5000, debug=True)